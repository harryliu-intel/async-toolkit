/*
 * Autodep - automatic maintenance of make dependancies
 * Copyright (c) 1999 Greg Banks
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef _autodep_h_
#define _autodep_h_

/*
 * $Id: autodep.h,v 1.6 1999/04/28 14:52:37 gnb Exp $
 */

#include <config.h>
#include <stdio.h>
#include <assert.h>
#include "patchlevel.h"
#include "common.h"


#if HAVE_LD_PRELOAD || HAVE_TRANSITIVE_LINK || HAVE_DLOPEN
#define HAVE_SHLIB 1
#else
#define HAVE_SHLIB 0
#endif

/*------------------------------------------------------------*/
/*
 * Structures.
 */


typedef struct
{
    enum { EXCLUDE=0, INCLUDE=1} in;
    const char *re;
} Pattern;

typedef enum { AUTO, PTRACE, SHLIB } SpawnMethod;

typedef struct
{
    char *name;
    Pattern *readPatterns;
    Pattern *writePatterns;
    bool (*autoMode)(const char *childArgv0);
    SpawnMethod preferredSpawnMethod;
} Language;


/*------------------------------------------------------------*/
/*
 * Functions
 */

/* files.c */
void fileOpened(int flags, const char *filename);
void saveDependancies(void);
/* match.c */
int match(const char *string, const char *pattern);
/* lang.c */
bool setLanguage(const char *lang, const char *childArgv0);
char *listLanguages(void);
Language *getLanguage(void);
/* spawn_shlib.c */
int spawnChildShlib(char **argv);
/* spawn_ptrace.c */
int spawnChildPtrace(char **argv);
/* util.c */
const char *pathtail(const char *path);
char *pathbase(const char *path);


/*extern char *strdup(const char *);*/
extern int putenv(const char *);
extern int strcasecmp(const char *s1, const char *s2);

/*------------------------------------------------------------*/
/*
 * Global variables
 */

extern const char *argv0;
extern const char *outputFilename;

/*------------------------------------------------------------*/
#endif /* _autodep_h_ */
