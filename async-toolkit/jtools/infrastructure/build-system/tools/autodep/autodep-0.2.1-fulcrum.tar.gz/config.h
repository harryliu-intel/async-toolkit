/* config.h.  Generated automatically by configure.  */
/*
 * Autodep - automatic maintenance of make dependancies
 * Copyright (c) 1999 Greg Banks
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef _config_h_
#define _config_h_ 1

/*
 * $Id: config.h.in,v 1.1 1999/04/28 14:52:37 gnb Exp $
 */

/*
 * Define as non-zero to turn on debugging prints.
 */
#define DEBUG 0

/*
 * Hardcoded file descriptor used for the write end
 * of the pipe from the inserted shared library and
 * the wrapper program (in the shlib technique).
 * Carefully chosen not to clash with Purify.
 */
#define OUTPUT_FD	29

/*
 * Full pathname to the real libc shared library,
 * needed for the dlopen() variant of the shlib
 * technique.
 * Comes from Makefile now.
 */
/* #define LIBC		"/lib/libc.so.5" */

/*
 * Name of the environment variable which tells
 * the runtime linker a searchpath of directories
 * in which to find shared libraries.
 */
#define SO_PATH_VAR	"LD_LIBRARY_PATH"


/*
 * The directory into which autodep's own
 * inserted shared library in installed.
 * Comes from Makefile now.
 */
/* #define LIBDIR		"/usr/local/lib/autodep" */


/*
 * The basename of autodep's own inserted
 * shared library. Needed for the LD_PRELOAD
 * variant of the shlib technique.
 * Comes from Makefile now.
 */
/* #define AUTODEP_SO	"autodep.so" */

/*
 * Default value of the filename to which
 * dependancies are written. Can be changed
 * at runtime with the -o option. See manpage.
 */
#define OUTPUT_FILENAME "%F.dep"


/*
 * Whether the SIGCHLD handler routine
 * needs to be re-registered everytime
 * it's called.
 */
#define MUST_RECATCH_SIGCHLD 1


/*
 * Whether the runtime linker supports the
 * $LD_PRELOAD environment variable, which
 * contains the full pathname of a single
 * shared library to be mapped into the
 * process before all others. Currently
 * this is only supported on Linux & Solaris.
 */
#define HAVE_LD_PRELOAD 1

/*
 * Whether the runtime linker supports
 * transitive linking, in which case the
 * autodep shared library is built to
 * depend on the real libc.
 */
#define HAVE_TRANSITIVE_LINK 0

/*
 * Whether the OS supports dlopen() in a
 * separate library so that it can be called
 * to map libc.
 */
#define HAVE_DLOPEN 0

/*
 * Whether the ptrace(2) system call is defined,
 * and has the PTRACE_SYSCALL request (continue
 * until next system call) or equivalent, and works.
 * Currently only Linux, Solaris, and SunOS.
 */
#define HAVE_PTRACE 1


/*
 * Whether the OS provides a special file (e.g. in a
 * /proc filesystem) by which a file descriptor can be
 * opened which will allow read and seek of the
 * inferior process' memory space. Currently Linux.
 */
#define HAVE_MEM_FD 1


/*
 * If HAVE_MEM_FD is set, MEM_PATHNAME is the pathname
 * to open, %d is expanded to the pid of the inferior process.
 */
#define MEM_PATHNAME	"/proc/%d/mem"

/*
 * If AUTODEP_LANG_C is set, support is built in
 * to detect dependancies from runs of C compilers.
 */
#define AUTODEP_LANG_C 1

/*
 * If AUTODEP_LANG_C is set, support is built in
 * to detect dependancies from runs of C++ compilers.
 */
#define AUTODEP_LANG_CXX 1

/*
 * If AUTODEP_LANG_C is set, support is built in
 * to detect dependancies from runs of the Java compiler.
 */
#define AUTODEP_LANG_JAVA 1

/* TODO: define variables to control whether to overload _libc_open etc */

/* Various standard autoconf defines */
#define HAVE_FCNTL_H 1
#define HAVE_MALLOC_H 1
#define HAVE_MEMORY_H 1
#define HAVE_STRCHR 1
#define HAVE_SYS_WAIT_H 1
#define HAVE_UNISTD_H 1
#define STDC_HEADERS 1
#define RETSIGTYPE void

#endif /* _config_h_ */
