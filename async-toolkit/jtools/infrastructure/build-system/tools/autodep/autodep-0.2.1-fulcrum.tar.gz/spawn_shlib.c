/*
 * Autodep - automatic maintenance of make dependancies
 * Copyright (c) 1999 Greg Banks
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "autodep.h"
#include <signal.h>
#include "msgheader.h"

CVSID("$Id: spawn_shlib.c,v 1.3 1999/04/28 14:52:37 gnb Exp $");

#if HAVE_SHLIB

/*------------------------------------------------------------*/

static bool childChanged = FALSE;

static RETSIGTYPE
sigchld_handler(int sig)
{
#if DEBUG
    fprintf(stderr, "sigchld_handler\n");
#endif

    childChanged = TRUE;
#if MUST_RECATCH_SIGCHLD
    signal(SIGCHLD, sigchld_handler);
#endif
}

/*------------------------------------------------------------*/

static void
waitForChild(pid_t rootpid, int *retp)
{
    pid_t pid;
    int status;

    pid = wait(&status);

#if DEBUG
    fprintf(stderr, "waitForChild(): returned pid %d\n", (int)pid);
#endif

    if (pid < 0)
    {
	if (errno != ECHILD)
	    perror("wait");
    }
    else if (WIFEXITED(status))
    {
#if DEBUG
	fprintf(stderr, "%s: child [%d] exited with exit code %d\n",
	    argv0, (int)pid, WEXITSTATUS(status));
#endif
	if (pid == rootpid)
	    *retp = WEXITSTATUS(status);
    }
    else if (WIFSIGNALED(status))
    {
	/* Keep the message, otherwise this info will be lost */
	fprintf(stderr, "%s: child [%d] terminated on signal %d\n",
	    argv0, (int)pid, WTERMSIG(status));
	if (pid == rootpid)
	    *retp = 1;
    }
    else if (WIFSTOPPED(status))
    {
	fprintf(stderr, "%s: child [%d] stopped on signal %d\n",
	    argv0, (int)pid, WSTOPSIG(status));
    }
}


/*------------------------------------------------------------*/

static int
mainLoop(pid_t rootpid, int readfd)
{
    int nread;
    struct msgheader hdr;
    int ret = -1;
    char buf[10240];

    signal(SIGCHLD, sigchld_handler);

    /*
     * Loop while pipe still open or root child not exited yet.
     */
    while (readfd >= 0 || ret < 0)
    {
	if (childChanged)
	{
	    childChanged = FALSE;
	    waitForChild(rootpid, &ret);
	}

    	if (readfd >= 0)
	{
	    /*
	     * Pipe still open - block waiting for input
	     * or interrupted with child changes.
	     */
	    nread = read(readfd, &hdr, sizeof(hdr));

	    if (nread == sizeof(hdr))
	    {
		assert(hdr.length < sizeof(buf));
		read(readfd, buf, hdr.length);
		buf[hdr.length] = '\0';
		fileOpened((hdr.access == 'R' ? O_RDONLY : O_WRONLY), buf);
	    }
	    else if (nread == 0)
	    {
		/* end of file */
		close(readfd);
		readfd = -1;
	    }
	    else if (nread < 0)
	    {
		if (childChanged)
		{
		    /*interrupted by SIGCHLD*/
		    childChanged = FALSE;
		    waitForChild(rootpid, &ret);
		}
		else
		{
		    perror("read");
		}
	    }
	    else
	    {
		fprintf(stderr, "%s: error: short read (%d/%d bytes)\n",
		    argv0, nread, sizeof(hdr));
		break;
	    }
	}
	else
    	{
	    /*
	     * Pipe has drained & been closed, so
	     * just block waiting for a child
	     */
	    waitForChild(rootpid, &ret);
	}
    }

#if DEBUG
    fprintf(stderr, "mainLoop(): returning %d\n", ret);
#endif

    return ret;
}

/*------------------------------------------------------------*/

#if DEBUG
#define PUTENV(str) myputenv2(str)
static int
myputenv2(const char *str)
{
    fprintf(stderr, "putenv(%s)\n", str);
    return putenv(str);
}
#else
#define PUTENV(str) putenv(str)
#endif


static void
modifyEnvironment(void)
{
#if HAVE_LD_PRELOAD
    PUTENV("LD_PRELOAD="LIBDIR"/"AUTODEP_SO);
#else
    char *var = SO_PATH_VAR, *libdir = LIBDIR, *oldpath, *newpath;

    oldpath = getenv(var);
    if (oldpath == 0)
    {
	newpath = malloc(strlen(var)+2+strlen(libdir));
	sprintf(newpath, "%s=%s", var, libdir);
    }
    else
    {
	newpath = malloc(strlen(var)+3+strlen(oldpath)+strlen(libdir));
	sprintf(newpath, "%s=%s:%s", var, libdir, oldpath);
    }
    PUTENV(newpath);
#endif
}

/*------------------------------------------------------------*/

#define READ	0
#define WRITE	1

int
spawnChildShlib(char **argv)
{
    pid_t pid;
    int pipefds[2];

    modifyEnvironment();

    if (pipe(pipefds) < 0)
    {
    	perror("pipe");
    	exit(2);
    }

    switch (pid = fork())
    {
    case 0:	/* child */
	close(pipefds[READ]);
	dup2(pipefds[WRITE], OUTPUT_FD);
	close(pipefds[WRITE]);
    	execvp(argv[0], argv);
    	perror(argv[0]);
    	exit(1);
    case -1:	/* error */
    	perror("fork");
    	return 1;
    default:	/* parent */
	close(pipefds[WRITE]);
	return mainLoop(pid, pipefds[READ]);
    }
}

#undef READ
#undef WRITE

#endif /* HAVE_SHLIB */
/*------------------------------------------------------------*/
/*END*/
