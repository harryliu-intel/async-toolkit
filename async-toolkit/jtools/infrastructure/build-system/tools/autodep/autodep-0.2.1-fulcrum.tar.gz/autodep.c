/*
 * Autodep - automatic maintenance of make dependancies
 * Copyright (c) 1999 Greg Banks
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "autodep.h"

CVSID("$Id: autodep.c,v 1.6 1999/04/27 16:12:18 gnb Exp $");

const char *argv0;
const char *outputFilename = OUTPUT_FILENAME;

static SpawnMethod spawnMethod = AUTO;

/*------------------------------------------------------------*/

static void
printLangs(FILE *fp)
{
    /* memleak but who cares in such a shortlived executable */
    fprintf(fp, "Languages supported by this executable:%s\n",
    	listLanguages());
}

static const char
usageString[] = 
"Usage: %s [options] compiler compilerargs\n"
"\n"
"  options are:\n"
"-v|--version		print version and exit\n"
"-h|--help		print this message\n"
"-o|--output file	set dependancy filename (see manpage for %% sequences)\n"
"-l|--lang str		set the compiler language (default \"auto\")\n"
"--print-langs		list all languages and exit\n"
#if HAVE_SHLIB
"-s|--shlib		use the shlib method to trace open(2) calls\n"
#endif
#if HAVE_PTRACE
"-p|--ptrace		use the ptrace(2) method to trace open(2) calls\n"
#endif
"\n"
"  "
;

static void
usage()
{
    fprintf(stderr, usageString, argv0);
    printLangs(stderr);
    exit(1);
}

static const char versionString[] = 
"Autodep version " VERSION ", Copyright (c) 1999 Greg Banks\n"
"Autodep comes with ABSOLUTELY NO WARRANTY; for details the file COPYING.\n"
"This is free software, and you are welcome to redistribute it\n"
"under certain conditions; see the file COPYING for details.\n";


static int
parseArguments(int argc, char **argv)
{
    int i;
    const char *lang = "auto";

    argv0 = argv[0];

    for (i=1 ; i<argc ; i++)
    {
    	if (argv[i][0] != '-')
	    break;	/* first non-option ends options, is child argv0 */

	if (!strcmp(argv[i], "-v") || !strcmp(argv[i], "--version"))
	{
	   fputs(versionString, stdout);
	   exit(0);
	}
	if (!strcmp(argv[i], "-h") || !strcmp(argv[i], "--help"))
	{
	   usage();
	}
	if (!strcmp(argv[i], "-l") || !strcmp(argv[i], "--lang"))
	{
	    lang = argv[++i];
	}
	if (!strcmp(argv[i], "-p") || !strcmp(argv[i], "--ptrace"))
	{
	    spawnMethod = PTRACE;
	}
	if (!strcmp(argv[i], "-s") || !strcmp(argv[i], "--shlib"))
	{
	    spawnMethod = SHLIB;
	}
	if (!strcmp(argv[i], "-o") || !strcmp(argv[i], "--output"))
	{
	    outputFilename = argv[++i];
	}
	if (!strcmp(argv[i], "--print-langs"))
	{
	    printLangs(stdout);
	    exit(0);
	}
    }

    if (i == argc)
    	usage();	/* must be at least 1 arg left over */

    if (!setLanguage(lang, argv[i]))
    {
	if (!strcasecmp(lang, "auto"))
	    fprintf(stderr, "%s: unable to autodetect language. Try using the --lang option.\n", argv0);
	else
	    fprintf(stderr, "%s: unknown language \"%s\".\n", argv0, lang);
	printLangs(stderr);
	exit(1);
    }


    if (spawnMethod == AUTO)
    	spawnMethod = getLanguage()->preferredSpawnMethod;

    if (spawnMethod == AUTO)
    {
#if HAVE_SHLIB
	spawnMethod = SHLIB;
#elif HAVE_PTRACE
	spawnMethod = PTRACE;
#else
#error "No spawn method configured."
#endif
    }

#if !HAVE_SHLIB
    if (spawnMethod == SHLIB)
    {
	fprintf(stderr, "%s: this executable does not support --shlib\n",
		argv0);
	exit(1);
    }
#endif
#if !HAVE_PTRACE
    if (spawnMethod == PTRACE)
    {
	fprintf(stderr, "%s: this executable does not support --ptrace\n",
		argv0);
	exit(1);
    }
#endif


    return i;
}

/*------------------------------------------------------------*/

static int
spawnChild(char **argv)
{

#if HAVE_SHLIB
    if (spawnMethod == SHLIB)
    	return spawnChildShlib(argv);
#endif

#if HAVE_PTRACE
    if (spawnMethod == PTRACE)
    	return spawnChildPtrace(argv);
#endif

    assert(spawnMethod != AUTO);
    return 1;
}

/*------------------------------------------------------------*/

int
main(int argc, char **argv)
{
    int ret;
    int nskip;

    nskip = parseArguments(argc, argv);

    ret = spawnChild(argv+nskip);

    if (ret == 0)
	saveDependancies();

    return ret;
}

/*------------------------------------------------------------*/
/*END*/
