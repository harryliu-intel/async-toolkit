/*
 * Autodep - automatic maintenance of make dependancies
 * Copyright (c) 1999 Greg Banks
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <config.h>
#include <syscall.h>
#include <stdarg.h>
#include "common.h"
#include "msgheader.h"
#include "patchlevel.h"
#if DEBUG
#include <stdio.h>
#endif

CVSID("$Id: shlib.c,v 1.6 1999/04/28 14:52:37 gnb Exp $");

#if DEBUG
static const char *_autodep_argv0(void);
#endif

/*------------------------------------------------------------*/

#ifdef __GNUC__
/*
 * This gcc-specific magic causes the _autodep_init()
 * function to be automatically called when the
 * library is mapped. On ELF systems this is done by
 * by sticking it in the .init section rather than .text.
 */
static void _autodep_init(void) __attribute__((constructor));
#endif

static void
_autodep_init(void)
{
#if HAVE_DLOPEN
    /*
     * Without LD_PRELOAD or runtime transitive link, need to
     * load up the real libc in the _init() function which is
     * called as soon as the library is mapped.
     */
    if (dlopen(LIBC, 0) == 0)
    {
	/* without libc, no way to write a message !!! */
	exit(127);
    }
#endif
#if DEBUG
    fprintf(stderr, "%s[%d] _init()\n", _autodep_argv0(), (int)getpid());
#endif
}

#ifndef __GNUC__
void
_init(void)
{
    _autodep_init();
}
#endif

/*------------------------------------------------------------*/

static int
_autodep_open(const char *filename, int flags, int mode, const char *fn)
{
    static int fd = OUTPUT_FD;
    int result, terrno;

#if DEBUG
    fprintf(stderr, "[%d] %s(\"%s\", %d)\n",
    	(int)getpid(), fn, filename, flags);
#endif

    result = syscall(SYS_open, filename, flags, mode);
    terrno = errno;

    if (result >= 0 && fd >= 0)
    {
    	struct msgheader hdr;

    	switch (flags & O_ACCMODE)
	{
    	case O_RDONLY:
    	    hdr.access = 'R';
    	    break;
    	case O_WRONLY:
    	    hdr.access = 'W';
    	    break;
	default:
    	    hdr.access = '\0';
	    /*fprintf( stderr, "%s not opened R or W\n", filename ); */
    	    break;
    	}
    	if (hdr.access)
	{
	    hdr.length = strlen(filename);
	    if (write(fd, &hdr, sizeof(hdr)) < 0)
	    {
	        if (errno == EBADF)
		    fd = -1;
	    }
	    else
		write(fd, filename, hdr.length);
	}
	errno = terrno;
    }

    return result;
}

/*------------------------------------------------------------*/


#define DEFINE_OPEN_FUNCTION(fn) \
int \
fn(const char *filename, int flags, ...) \
{ \
    va_list args; \
    int mode; \
 \
    va_start(args, flags); \
    mode = va_arg(args, int); \
    va_end(args); \
 \
    return _autodep_open(filename, flags, mode, #fn); \
}


#if ( __GLIBC__ - 0 ) >= 2
/* Newer glibc, e.g. on most recent Linux distros */
DEFINE_OPEN_FUNCTION(__open)
DEFINE_OPEN_FUNCTION(__libc_open)
#endif

DEFINE_OPEN_FUNCTION(open)

/*------------------------------------------------------------*/

#if DEBUG

static const char *
_autodep_argv0(void)
{
#ifdef __linux
    static char argv0[256] = "";
    
    if (argv0[0] == '\0')
    {
	int fd;
	char fn[256];

	sprintf(fn, "/proc/%d/cmdline", (int)getpid());
	fd = syscall(SYS_open, fn, O_RDONLY, 0);
	if (fd >= 0)
    	{
	    read(fd, argv0, sizeof(argv0));
	    close(fd);
	}
    }
    return argv0;
#else
    return "";
#endif
}

#endif

/*------------------------------------------------------------*/
/*END*/
