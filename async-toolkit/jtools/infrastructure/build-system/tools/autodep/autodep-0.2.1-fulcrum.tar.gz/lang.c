/*
 * Autodep - automatic maintenance of make dependancies
 * Copyright (c) 1999 Greg Banks
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "autodep.h"

CVSID("$Id: lang.c,v 1.4 1999/04/27 16:12:18 gnb Exp $");

#if AUTODEP_LANG_C
extern Language language_c;
#endif
#if AUTODEP_LANG_CXX
extern Language language_cxx;
#endif
#if AUTODEP_LANG_JAVA
extern Language language_java;
#endif

static Language *languages[] = 
{
#if AUTODEP_LANG_C
&language_c,
#endif
#if AUTODEP_LANG_CXX
&language_cxx,
#endif
#if AUTODEP_LANG_JAVA
&language_java,
#endif
0
};

static Language *theLang = 0;

bool
setLanguage(const char *lang, const char *childArgv0)
{
    int i;

    if (!strcasecmp(lang, "auto"))
    {
	for (i=0 ; languages[i] != 0 ; i++)
	    if ((*languages[i]->autoMode)(childArgv0))
	    {
	    	theLang = languages[i];
#if DEBUG
		fprintf(stderr, "setLanguage(): autodetected language \"%s\"\n",
			theLang->name);
#endif
	    	return TRUE;
	    }
    }
    else
    {
	for (i=0 ; languages[i] != 0 ; i++)
	    if (!strcasecmp(languages[i]->name, lang))
	    {
	    	theLang = languages[i];
#if DEBUG
		fprintf(stderr, "setLanguage(): matched language \"%s\"\n",
			theLang->name);
#endif
	    	return TRUE;
	    }
    }
    return FALSE;
}


/*
 * Build and return a new string (which caller should free
 * with free()) containing list of all supported languages
 * separated by commas.
 */

char *
listLanguages(void)
{
    int i, len;
    char *str;

    len = 5;	/* strlen("auto")+1 */
    for (i=0 ; languages[i] != 0 ; i++)
    	len += strlen(languages[i]->name)+1;

    str = malloc(len);
    if (str == 0)
    	return 0;

    str[0] = '\0';
    for (i=0 ; languages[i] != 0 ; i++)
    {
	if (i)
	    strcat(str, ",");
    	strcat(str, languages[i]->name);
    }
    strcat(str, ",auto");
    	
    return str;
}

Language *
getLanguage(void)
{
   return theLang;
}
