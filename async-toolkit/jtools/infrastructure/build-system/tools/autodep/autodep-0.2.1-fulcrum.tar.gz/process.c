/*
 * Autodep - automatic maintenance of make dependancies
 * Copyright (c) 1999 Greg Banks
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "process.h"
#include <sys/syscall.h>	/* for SYS_fork */
#include <sys/ptrace.h>		/* for PTRACE_* */
#include <sys/user.h>		/* for struct user */
#include <stdio.h>
#include <assert.h>

CVSID("$Id: process.c,v 1.4 1999/04/28 14:52:37 gnb Exp $");

#if HAVE_PTRACE

#define offset(t, m)		((size_t)(&((t *)0)->m))

/*
 * Older Linux kernel didn't quite get this define right.
 * In the newer (2.2.x) kernel, PTRACE_PEEKUSER is an
 * enum so we can't #if test it.
 */
#if defined(__linux) && defined(PTRACE_PEEKUSR)
#define PTRACE_PEEKUSER		PTRACE_PEEKUSR
#endif

/*------------------------------------------------------------*/

static Word	readUserStruct(Process *ps, int offset);
static Addr	getPc(Process *ps);
static int	swapText(Process *ps, Addr addr, Word *inout);

static Process *all_ = 0;

/*------------------------------------------------------------*/


Process *
processNew(pid_t pid)
{
    Process *ps = (Process *)malloc(sizeof(Process));

    ps->pid_ = pid;
    ps->flags_ = 0;
    ps->stopState_ = STARTUP;
    ps->memFd_ = -1;
    ps->numTracedChildren_ = 0;

    /* Insert at head of chain of Process objects */
    if (all_ != 0)
    	all_->prev_ = ps;
    ps->next_ = all_;
    ps->prev_ = 0;
    all_ = ps;

    return ps;
}

void
processDelete(Process *ps)
{
    if (ps == 0)
    	return;

#if HAVE_MEM_FD
    if (ps->memFd_ >= 0)
	close(ps->memFd_);
#endif
    if (ps->parent_ != 0)
    	ps->parent_->numTracedChildren_++;

    /* Remove from chain of Process objects */
    if (ps->prev_ != 0)
    	ps->prev_->next_ = ps->next_;
    if (ps->next_ != 0)
    	ps->next_->prev_ = ps->prev_;
    if (all_ == ps)
    	all_ = ps->next_;

    free(ps);
}

Process *
processFind(pid_t pid)
{
    Process *ps;

    for (ps = all_ ; ps != 0 ; ps = ps->next_)
    {
    	if (ps->pid_ == pid)
	    return ps;
    }
    return 0;
}

/*------------------------------------------------------------*/

/*
 * Linux on Intel x86.
 */
#ifdef __linux

#ifndef __i386__
#error Linux only supported on x86, sorry
#endif

/*
 * x Register EAX as originally passed into system call, stored in
 *   the user struct as regs.orig_eax, holds the system call number.
 * x Register EAX as returned from the system call (regs.eax), is a
 *   negative error code if an error occurred, or the return code
 *   if positive.
 *
 * Note: actually this offset(struct user, ...) stuff is a complete
 *       fantasy, at least for kernel version 1.2.11, because ptrace()
 *       does not allow us access to any kernel structure, in fact
 *       Linux doesn't *have* a user struct in the traditional Unix
 *       sense but instead fakes it for ptrace() and coredumps. To
 *       be realistic we should use the register symbols in <ptrace.h>.
 */
int
processSystemCallNumber(Process *ps)
{
    return readUserStruct(ps, offset(struct user, regs.orig_eax));
}

bool
processSystemCallReturnError(Process *ps, Word *retp, Word *errp)
{
    Word eax;

    eax = readUserStruct(ps, offset(struct user, regs.eax));
    if (eax == -1 && errno)
    {
    	/* error getting other process' error code */
    	perror("ptrace");
    	return FALSE;
    }
    if (eax >= 0)
    {
	/* no error code in other process */
	*retp = eax;
	*errp = 0;
    }
    else
    {
	/* recognised error code */
	*retp = -1;
	*errp = -eax;
    }
    return TRUE;
}

Word
processSystemCallArg(Process *ps, int n)
{
    return readUserStruct(ps, n*4);
}

#endif

/*------------------------------------------------------------*/

/*
 * SunOS 4 on SPARC.
 */
#ifdef __sunos4

#ifndef __sparc
#error SunOS only supported on SPARC
#endif

/*
 * x  Register %o0, stored in the user struct as u_arg[7],
 *    holds the system call number
 * x  System call error number stored in user struct as u_error.
 *    Return value is in rval1.
 */
int
processSystemCallNumber(Process *ps)
{
    return readUserStruct(ps, offset(struct user, u_arg[7]));
}

bool
processSystemCallReturnError(Process *ps, Word *retp, Word *errp)
{
    Word ret, en;

    ret = readUserStruct(ps, offset(struct user, u_rval1));
    if (ret == -1 && errno)
    {
    	perror("ptrace");
	return FALSE;
    }
    *retp = ret;

    en = readUserStruct(ps, offset(struct user, u_error));
    if (en == -1 && errno)
    {
    	perror("ptrace");
	return FALSE;
    }
    *errp = (en>>24);
    return TRUE;
}


#endif

/*------------------------------------------------------------*/

#ifdef SVR4

int
processSystemCallNumber(Process *ps)
{
    int scno;

    /* Read status from /proc/pid using PIOCSTATUS ioctl */
#if HAVE_PR_SYSCALL
    /* And return status.pr_syscall */
#else
    /* And return status.pr_what */
#endif
    return scno;
}

#endif

/*------------------------------------------------------------*/

void
processContinueUntilSystemCall(Process *ps)
{
    if (ps->flags_ & PF_SUSPEND)
    	return;
#if HAVE_PTRACE
    ptrace(PTRACE_SYSCALL, ps->pid_, 1, 0);
#endif
}

/*------------------------------------------------------------*/

int
processReadDataSpace(Process *ps, Addr offset, int len, char *buf)
{
#if HAVE_MEM_FD

#if DEBUG
    fprintf(stderr, "processReadDataSpace([%d], offset=0x%08x, len=%d\n",
    	(int)ps->pid_, (unsigned)offset, len);
#endif

    if (ps->memFd_ < 0)
    {
        char buf[32];
    	sprintf(buf, MEM_PATHNAME, (int)ps->pid_);
    	if ((ps->memFd_ = open(buf, O_RDONLY, 0)) < 0)
    	    return -1;
    }
    lseek(ps->memFd_, offset, SEEK_SET);
    return read(ps->memFd_, buf, len);
#else
    int i;

    assert(offset % sizeof(Word) == 0);
    assert(len % sizeof(Word) == 0);
    for (i=0 ; i<len ; i+=sizeof(Word))
    {
    	int *p = (int *)(buf+i);
    	*p = ptrace(PTRACE_PEEKDATA, ps->pid_, offset+i, 0);
    	if (*p == -1 && errno)
    	    break;
    }
    return i-sizeof(Word);
#endif
}

static int
readUserStruct(Process *ps, int offset)
{
    return ptrace(PTRACE_PEEKUSER, ps->pid_, offset, 0);
}

/*------------------------------------------------------------*/

void
processPrepareToBeTraced(void)
{
#if DEBUG
    fprintf(stderr, "child [%d] preparing to be traced\n", (int)getpid());
#endif
#if HAVE_PTRACE
    ptrace(PTRACE_TRACEME, getpid(), 0, 0);
#endif
}

/*------------------------------------------------------------*/

bool
processAttach(Process *ps)
{
    if (ptrace(PTRACE_ATTACH, ps->pid_, 1, 0) < 0)
    	return FALSE;
    /*
     * TODO: ifdef __linux ???
     * Calling ptrace(PTRACE_ATTACH...) will stop the
     * inferior with SIGSTOP rather than SIGTRAP.
     */
    ps->flags_ |= PF_ATTACHED|PF_EXPECTSTOP;
    return TRUE;
}

/*------------------------------------------------------------*/

/*
 * Low level operations to get a process' current PC and
 * to swap a word back and forth into its text segment.
 * Also define a word which is a loop-in-place instruction
 * for the given architecture.
 *
 * The PC handling code is horrendously hardware specific,
 * the swap code horribly OS specific.
 */

#if defined(__linux)

static Addr
getPc(Process *ps)
{
    return readUserStruct(ps, offset(struct user, regs.eip));
}

static int
swapText(Process *ps, Addr addr, Word *inout)
{
    Word old;

    old = ptrace(PTRACE_PEEKTEXT, ps->pid_, addr, 0);
    if (old == -1 && errno)
    	return -1;
    if (ptrace(PTRACE_POKETEXT, ps->pid_, addr, *inout) < 0)
    	return -1;
#if DEBUG
    fprintf(stderr, "swapText(0x%08x[%d]: 0x%08x <-> 0x%08x)\n",
    	addr, (int)ps->pid_, old, *inout);
#endif
    *inout = old;
    return 0;
}

#define I_LOOP	0x0000feeb		/* looping instruction (not LOOP) */

#elif defined(__sunos4)

static Addr
getPc(Process *ps)
{
    struct regs regs;
    if (ptrace(PTRACE_GETREGS, ps->pid_, (char*)&regs, 0) < 0)
    	return -1;
    return regs.r_o7 + 8;
}


int
swapText(Process *ps, Addr addr, Word *inout)
{
    Word old;

    if (ptrace(PTRACE_READTEXT, ps->pid_, addr, sizeof(Word), &old) < 0)
    	return -1;
    if (ptrace(PTRACE_WRITETEXT, ps->pid_, addr, sizeof(Word), inout) < 0)
    	return -1;
    *inout = old;
    return 0;
}

#define I_LOOP	0x30800000		/* ba,a 0  (loops in place) */

#else
#error getPc() and swapText() not defined for this configuration
#endif

/*------------------------------------------------------------*/

bool
processSetForkBreakpoint(Process *ps)
{
    assert(!(ps->flags_ & PF_BP_SET));

    if ((ps->forkBp_.addr_ = getPc(ps)) == -1)
    	return FALSE;

    ps->forkBp_.oldText_ = I_LOOP;
    swapText(ps, ps->forkBp_.addr_, &ps->forkBp_.oldText_);

    ps->flags_ |= PF_BP_SET;
    return TRUE;
}

bool
processClearForkBreakpoint(Process *ps)
{
    assert(ps->flags_ & PF_BP_SET);
    swapText(ps, ps->forkBp_.addr_, &ps->forkBp_.oldText_);
    ps->flags_ &= ~PF_BP_SET;
    return TRUE;
}

/*------------------------------------------------------------*/
#endif /* HAVE_PTRACE */
/*------------------------------------------------------------*/
/*END*/
