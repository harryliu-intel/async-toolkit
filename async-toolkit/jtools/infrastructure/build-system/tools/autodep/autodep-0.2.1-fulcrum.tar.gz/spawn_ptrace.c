/*
 * Autodep - automatic maintenance of make dependancies
 * Copyright (c) 1999 Greg Banks
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "autodep.h"
#include <sys/syscall.h>	/* for SYS_open */
#include <string.h>
#include <signal.h>
#include "process.h"

CVSID("$Id: spawn_ptrace.c,v 1.4 1999/04/28 14:52:37 gnb Exp $");

/*------------------------------------------------------------*/

#if defined(__sun) && !defined(__svr4)
/* SunOS 4 */
#define FORK_ATTACH_TRIES	1024
#else
#define FORK_ATTACH_TRIES	1
#endif

void
handleFork(Process *ps, bool before)
{
    if (before)
    {
    	processSetForkBreakpoint(ps);
    }
    else
    {
	Process *child;
	pid_t childpid;
	int i;
	bool hasBpt = (ps->flags_ & PF_BP_SET);
	Breakpoint forkBp;

    	if (hasBpt)
	{
	    forkBp = ps->forkBp_;
    	    processClearForkBreakpoint(ps);
	}
	if (ps->systemCall_.error_ > 0)
	    return;		/* fork() failed */

	childpid = ps->systemCall_.return_;
#if DEBUG
	fprintf(stderr, "Forked, childpid = %d\n", (int)childpid);
#endif
	child = processNew(childpid);
	child->parent_ = ps;
	ps->numTracedChildren_++;

	for (i=0 ; i<FORK_ATTACH_TRIES ; i++)
	{
#if DEBUG
	    fprintf(stderr, "Attaching to %d, try %d\n", (int)child->pid_, i);
#endif
	    if (processAttach(child))
	    	break;
	}
	if (i == FORK_ATTACH_TRIES)
	{
	    fprintf(stderr, "Couldn't attach to descendant process %d\n",
	    	(int)childpid);
	    return;
	}
	if (hasBpt)
	{
	    child->flags_ |= PF_BP_SET;
	    child->forkBp_ = forkBp;
	}
    }
}

/*------------------------------------------------------------*/

static void
handleSystemCall(Process *ps, bool before)
{
    if (before)
    	ps->systemCall_.number_ = processSystemCallNumber(ps);
    else
	processSystemCallReturnError(ps,
		&ps->systemCall_.return_, &ps->systemCall_.error_);


#if DEBUG
    fprintf(stderr, "Child [%d] %s system call #%d\n",
    	(int)ps->pid_,
	(before ? "before" : "after"),
	ps->systemCall_.number_);
#endif

    switch (ps->systemCall_.number_)
    {
    case SYS_fork:
	handleFork(ps, before);
	break;
    case SYS_wait4:
	if (before && ps->numTracedChildren_ > 0)
	{
	    /*
	     * Normally, the process would block in wait4()
	     * until one of its children died. However,
	     * because the children are being traced, that
	     * status change is reported to the tracing
	     * process instead and wait4() returns immediately
	     * with ECHILD (No child processes). Thus we have
	     * to fake a blocking wait4() by not continuing
	     * the wait4()ing process.
	     */
#if DEBUG
	    fprintf(stderr, "Suspending [%d]\n", (int)ps->pid_);
#endif
	    ps->flags_ |= PF_SUSPEND;
	}
	break;
    case SYS_execve:
	if (before)
	{
	    /*
	     * For some bizarre reason I cannot fathom,
	     * waitpid() returns TWICE for the end of
	     * system call `execve'. Maybe there's a
	     * good reason...maybe not, but this extra
	     * state hacks around it.
	     */
#if DEBUG
	    fprintf(stderr, "Setting EXECVEHACK flag\n");
#endif
	    ps->stopState_ = EXECVEHACK;
	}
	break;
    case SYS_open:
	if (!before /* && ps->systemCall_.error_ == 0 */) 
	{
	    /*
	     * Only care about successful completions of open(2).
	     */
	    int flags;
	    int copyret;
	    char filename[1024];

	    filename[0] = '\0';
	    copyret = processReadDataSpace(ps, processSystemCallArg(ps, 0),
		    sizeof(filename), filename);
	    filename[sizeof(filename)-1] = '\0';	/* JIC */
	    flags = processSystemCallArg(ps, 1);

#if DEBUG
	    fprintf(stderr, "Child [%d] open(\"%s\", 0%o)=%d, errno=%d copyret=%d\n",
		    (int)ps->pid_,
		    filename,
		    flags,
		    ps->systemCall_.return_,
		    ps->systemCall_.error_,
		    copyret);
#if 0
	    {
		static const char *regnames[17] = 
		{ "ebx", "ecx", "edx", "esi", "edi", "ebp", "eax", "ds",
		  "es", "fs", "gs", "orig_eax", "eip", "cs", "efl", "uesp",
		  "ss" };
		int i;
		Addr wvalue;
		char strvalue[1024];

		fprintf(stderr, "registers: ");
		for (i=0 ; i<17 ; i++)
		{
		    wvalue = processSystemCallArg(ps, i);
		    strvalue[0] = '\0';
		    processReadDataSpace(ps, wvalue, sizeof(strvalue), strvalue);
		    strvalue[sizeof(strvalue)-1] = '\0';
		    fprintf(stderr, "\n%s %08x \"%s\"",
			regnames[i],
			(unsigned)wvalue,
			strvalue);
		}
		fprintf(stderr, "\n");
	    }
#endif
#endif

	    if (ps->systemCall_.error_ == 0)
		fileOpened(flags, filename);
	}
    	break;
    }
    processContinueUntilSystemCall(ps);
}

/*------------------------------------------------------------*/

/*
 * Called on detecting the death of a descendant process.
 */

static void
handleDeath(Process *ps)
{
    if (ps->parent_ != 0 && ps->parent_->numTracedChildren_ > 0)
    {
    	/* detach from self && resume the suspended parent */
    	Process *pa = ps->parent_;

	ps->parent_->numTracedChildren_--;
	ps->parent_ = 0;

        if (pa->flags_ & PF_SUSPEND)
	{
#if DEBUG
	    fprintf(stderr, "Resuming [%d]\n", pa->pid_);
#endif
	    pa->flags_ &= ~PF_SUSPEND;
	    processContinueUntilSystemCall(pa);
	}
    }
    processDelete(ps);
}


/*------------------------------------------------------------*/

static void
handleStop(Process *ps)
{
#if DEBUG
    fprintf(stderr, "handleStop: [%d] state = %d\n",
    	(int)ps->pid_, (int)ps->stopState_);
#endif

    switch (ps->stopState_)
    {
    case STARTUP:
	ps->stopState_ = CALLBEGIN;
	if (ps->flags_ & PF_BP_SET)
	{
	    /* child process of fork() after attach succeeds. */
	    processClearForkBreakpoint(ps);
	    /* ps->stopState_ = CALLEND; */
	}
	processContinueUntilSystemCall(ps);
	break;

    case CALLBEGIN:
	ps->stopState_ = CALLEND;
	handleSystemCall(ps, TRUE);
	break;

    case CALLEND:
	ps->stopState_ = CALLBEGIN;
	handleSystemCall(ps, FALSE);
	break;

    case EXECVEHACK:
#if DEBUG
	fprintf(stderr, "Swallowing spurious execve\n");
#endif
	ps->stopState_ = CALLEND;	/* next will be the real call end */
	processContinueUntilSystemCall(ps);
	break;
    }
}

/*------------------------------------------------------------*/


static int
mainLoop(pid_t rootpid)
{
    Process *ps = processNew(rootpid);

    for (;;)
    {
    	pid_t pid;
	int status;

	pid = wait(&status);

#if DEBUG
	{
	    int terrno = errno;
	    fprintf(stderr, "wait() returned %d, errno=%d\n", (int)pid, terrno);
	    errno = terrno;
	}
#endif

	if (pid < 0)
	{
	    if (errno == ECHILD)
	    	return 1;		/* no more children */
	    /* TODO: care about interrupted system calls ... e.g. sigchld?? */
	    if (errno != EINTR)
		perror("wait");
	    continue;
	}

	if ((ps = processFind(pid)) == 0)
	{
	    /* Fine, we've reaped a process we didn't expect... */
#if DEBUG
	    fprintf(stderr, "Unexpected process %d, ignoring\n", (int)pid);
#endif
	    continue;
	}

	/* At this point, `pid' `status' and `ps' have valid values */

	if (WIFEXITED(status))
	{
#if DEBUG
	    fprintf(stderr, "%s: child [%d] exited with exit code %d\n",
		argv0, (int)pid, WEXITSTATUS(status));
#endif
	    handleDeath(ps);
	    if (pid == rootpid)
		return WEXITSTATUS(status);
	}
	else if (WIFSIGNALED(status))
	{
	    fprintf(stderr, "%s: child [%d] terminated on signal %d\n",
		argv0, (int)pid, WTERMSIG(status));
	    handleDeath(ps);
	    if (pid == rootpid)
		return 1;
	}
	else if (WIFSTOPPED(status))
	{
	    if (WSTOPSIG(status) == SIGSTOP && (ps->flags_ & PF_EXPECTSTOP))
	    {
#if DEBUG
		fprintf(stderr, "Child [%d] stopped on SIGSTOP as expected\n",
			(int)pid);
#endif
		/* First stop for inferior attach()ed to. */
		ps->flags_ &= ~PF_EXPECTSTOP;
		handleStop(ps);
		continue;
	    }
	    if (WSTOPSIG(status) == SIGTRAP)
	    {
#if DEBUG
		fprintf(stderr, "Child [%d] stopped on SIGTRAP\n", (int)pid);
#endif
		handleStop(ps);
		continue;
	    }
	    processContinueUntilSystemCall(ps);
	}
    }
}

/*------------------------------------------------------------*/

int
spawnChildPtrace(char **argv)
{
    pid_t pid;

    switch (pid = fork())
    {
    case 0:	/* child */
	processPrepareToBeTraced();
    	execvp(argv[0], argv);
    	perror(argv[0]);
    	exit(1);
    case -1:	/* error */
    	perror("fork");
    	return 1;
    default:	/* parent */
	return mainLoop(pid);
    }
}

/*------------------------------------------------------------*/
/*END*/
