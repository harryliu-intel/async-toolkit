/*
 * Autodep - automatic maintenance of make dependancies
 * Copyright (c) 1999 Greg Banks
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "autodep.h"

CVSID("$Id: match.c,v 1.3 1999/04/27 15:41:23 gnb Exp $");

/*
 * Very simple wildcard matching, based on a single '*'
 * character at either end or beginning or pattern.
 */

#if DEBUG
#define STRCMP(a, b) \
	(printf("strcmp(\"%s\", \"%s\")\n", (a), (b)), strcmp((a), (b)))
#define STRNCMP(a, b, n) \
	(printf("strncmp(\"%s\", \"%s\", %d)\n", (a), (b), (n)), strncmp((a), (b), (n)))
#else
#define STRCMP(a, b)		strcmp((a), (b))
#define STRNCMP(a, b, n)	strncmp((a), (b), (n))
#endif

int
match(const char *string, const char *pattern)
{
    int len;

    if (*pattern == '*') {
	if ((len = strlen(string)-strlen(pattern)) <= 0)
	    return 0;
	return !STRCMP(string+len+1, pattern+1);
    } else if (pattern[(len = strlen(pattern))-1] == '*')
    	return !STRNCMP(string, pattern, len-1);
    else
    	return !STRCMP(string, pattern);
}


#ifdef STANDALONE

static void
my_gets(char *buf, int maxlen)
{
    char *x;

    buf[0] = '\0';
    fgets(buf, maxlen, stdin);
    if ((x = strchr(buf, '\n')) != 0)
    	*x = '\0';
    if ((x = strchr(buf, '\r')) != 0)
    	*x = '\0';
}

int
main(int argc, char **argv)
{
    char string[1024];
    char pattern[1024];
    char desired[1024];
    int actual;

    for (;;) {
	my_gets(string, sizeof(string));
	my_gets(pattern, sizeof(pattern));
	my_gets(desired, sizeof(desired));
	if (feof(stdin))
	    break;

	actual = match(string, pattern);
	printf("match(\"%s\", \"%s\") = %d (expected %s)\n",
		string, pattern, actual, desired);
    }
    return 0;
}

#endif
