/*
 * Autodep - automatic maintenance of make dependancies
 * Copyright (c) 1999 Greg Banks
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef _process_h_
#define _process_h_

/*
 * $Id: process.h,v 1.4 1999/04/28 14:52:37 gnb Exp $
 */

#include "common.h"



typedef struct _Process Process;
typedef struct _Breakpoint Breakpoint;
typedef int Word;
typedef int Addr;

enum _Constants
{
    MAXARGS= 6
};
enum Flags
{
    PF_BP_SET		=1<<0,	/* fork breakpoint has been set */
    PF_ATTACHED		=1<<1,	/* used PTRACE_ATTACH not PTRACE_TRACEME */
    PF_SUSPEND		=1<<2,	/* we are faking block in wait4() */
    PF_EXPECTSTOP	=1<<3	/* expect SIGSTOP next */
};

struct _Breakpoint
{
    Addr addr_;
    Word oldText_;
};


struct _Process
{
    Process *next_, *prev_;
    pid_t pid_;
    int flags_;
    enum { STARTUP, CALLBEGIN, CALLEND, EXECVEHACK } stopState_;
    Process *parent_;
    int numTracedChildren_;
    struct
    {
	Word number_;
	Word return_;
	Word error_;
	Word args_[2];
    } systemCall_;
    Breakpoint forkBp_;
#if HAVE_MEM_FD
    int memFd_;
#endif
};


void		processPrepareToBeTraced(void);
Process		*processFind(pid_t pid);
Process		*processNew(pid_t pid);
void		processDelete(Process *ps);
void		processContinueUntilSystemCall(Process *ps);
bool		processAttach(Process *ps);
int		processSystemCallNumber(Process *ps);
bool		processSystemCallReturnError(Process *ps,
			Word *retp, Word *errp);
Word		processSystemCallArg(Process *ps, int n);
int		processReadDataSpace(Process *ps, Addr offset, int len,
			char *buf);
bool		processSetForkBreakpoint(Process *ps);
bool		processClearForkBreakpoint(Process *ps);

#endif /* _process_h_ */
